$(document).ready(function() {
    console.log('on js documentation.....');
    $('#fileLogo').on('change', function() {
        var img = $('<img/>', {
            id: 'dynamic',
            width:250,
            height:200
        }); 
        console.log('on upload...');
        var file = this.files[0];
        var reader = new FileReader();
        reader.onload = function(e) {
            $("#nameLogo").val(file.name);
            img.attr('src', e.target.result);
            $("#previewLogo").attr("data-content", $(img)[0].outerHTML);
        }
        reader.readAsDataURL(file);
    });
});
