$('#fileLogo').on('change', function() {
    console.log('on upload...');
    var file = this.files[0];
    var reader = new FileReader();
    reader.onload = function(e) {
        $("#nameLogo").val(file.name);
        img.attr('src', e.target.result);
        $("#previewLogo").attr("data-content", $(img)[0].outerHTML);
    }
    reader.readAsDataURL(file);
});

